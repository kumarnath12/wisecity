# WISECITY 

Live responsive website:(https://visthruth21.github.io/Wisecity/)

#

We are tackling the problem of responsable behaviour in a smart city. Everyday while we commute to work/while hanging around in the city , we come across many typical problems like dirty streets due to incorrect garbage disposal, potholes which are left open and street lights that are on during the day and many more.



#

How it works :

Its a simple mobile app, where you can report problems you see when you’re walking/hanging around in the city..

The typical problems like dirty streets due to incorrect garbage disposal, street lights left on during the day, non-functioning traffic lights . The user takes a picture of the problem and with the help of phones geolocation, information is provided to the municipalities in order to optimize their cleaning services .The users are rewarded with coins that can be redeemed at the municipal corporation to skip long queues or to avail small discounts on electricity/water bills.


#

